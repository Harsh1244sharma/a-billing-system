"""
URL configuration for alfa project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from mybill import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('create-bill/', views.create_bill, name='create_bill'),
    path('add-products/<int:bill_no>/', views.add_products, name='add_products'), 
    path("delete-product/<int:bill_no>/<int:pk>/", views.product_delete, name="product_delete"),
    path('bill/<int:bill_no>/', views.bill_detail, name='bill_detail'),
    path("edit-product/<int:bill_no>/<int:pk>/", views.product_edit, name="product_edit"),
]

