from django.apps import AppConfig


class MybillConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mybill'
