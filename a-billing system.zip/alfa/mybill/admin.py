from django.contrib import admin
from .models import Bill, Product

# Register models individually
admin.site.register(Bill)
admin.site.register(Product)

# Register your models here.
