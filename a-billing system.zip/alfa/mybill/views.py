from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Bill, Product
from decimal import Decimal

def create_bill(request):
    if request.method == "POST":
        customer_name = request.POST.get("customer_name")
        phn = request.POST.get("number")
        bill = Bill.objects.create(customer_name=customer_name , phn=phn)
        return redirect("add_products", bill_no=bill.bill_no)
    return render(request, "create_bill.html")

def add_products(request, bill_no):
    bill = Bill.objects.get(bill_no=bill_no)
    if request.method == "POST":
        name = request.POST.get("name")
        quantity = int(request.POST.get("quantity"))
        price = float(request.POST.get("price"))
        exp = request.POST.get("exp", None)
        Product.objects.create(bill=bill, name=name, quantity=quantity, price=price, exp=exp)
    products = bill.products.all()
    total_amount = sum([p.total() for p in products])
    return render(request, "add_products.html", {
        "bill": bill,
        "products": products,
        "total_amount": total_amount
    })
def product_edit(request, pk, bill_no): 
    product = get_object_or_404(Product, pk=pk, bill__bill_no=bill_no) 
    if request.method == "POST":
         product.name = request.POST.get("name")
         product.quantity = int(request.POST.get("quantity")) 
         product.price = float(request.POST.get("price")) 
         product.exp = request.POST.get("exp", None)
         product.save() 
         messages.success(request,"product updated successfully")
         return redirect("add_products", bill_no=bill_no)
    return render(request, "product_edit.html", {"product": product, "bill_no": bill_no})

def product_delete(request, bill_no, pk):
    product = get_object_or_404(Product, pk=pk, bill__bill_no=bill_no)
    product.delete()
    messages.success(request,"product deleted successfully")
    return redirect("add_products", bill_no=bill_no)


def bill_detail(request, bill_no):
    bill = Bill.objects.get(bill_no=bill_no)
    products = bill.products.all()
    total_amount = sum([p.total() for p in products])
    tax = total_amount * Decimal(0.05)  # Example: 10% tax
    discount  = total_amount * Decimal(0.10)  # Example: 5% discount
    total_rate = total_amount + tax - discount
    context = {
        "bill": bill,
        "products": products,
        "total_amount": total_amount,
        "tax": tax,
        "discount": discount,
        "total_rate": total_rate
    }
    return render(request, "bill_detail.html", context)




                  




