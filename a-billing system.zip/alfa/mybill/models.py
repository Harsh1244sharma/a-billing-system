from django.db import models

class Bill(models.Model):
    bill_no = models.AutoField(primary_key=True)   # Auto-generate bill number
    customer_name = models.CharField(max_length=100)
    # Use CharField for phone numbers (IntegerField doesn't accept max_length
    # and phone numbers may include leading zeros or symbols)
    phn = models.CharField(max_length=15, default='0000000000')
    date = models.DateTimeField(auto_now_add=True)
    @property 
    def formatted_bill_no(self):
        return f"S-{self.bill_no:04d}"
    def __str__(self):
        return f"Bill {self.formatted_bill_no} - {self.customer_name} - {self.phn}"
class Product(models.Model):
    bill = models.ForeignKey(Bill, related_name="products", on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    quantity = models.IntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    exp = models.CharField(max_length=100, null=True, blank=True)  

    def total(self):
        return self.quantity * self.price

    def __str__(self):
        return f"{self.name} ({self.quantity} x {self.price})"


  
